
// Online IDE - Code Editor, Compiler, Interpreter
#include<iostream> // 含括iostream档案
#include<string.h> // 含括cstdlib档案
using namespace std; // 使用std名称空间
string a,b,c;
int main()
{
    cout<<"请输入班级：";
    cin>>a;
    cout<<"请输入学号：";
    cin>>b;
    cout<<"请输入姓名：";
    cin>>c;
    cout<<"-------"<<endl<<"班级："<<a<<endl<<"学号："<<b<<endl<<"姓名："<<c;
    return 0;
}
